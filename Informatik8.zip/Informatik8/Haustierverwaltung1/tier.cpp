#include "tier.hpp"
#include <iostream>

using namespace std;

Haustier::Haustier(std::string name, int alter, bool istSaeugetier)
{
    this->name = name;
    this->alter = alter;
    this->istSaeugetier = istSaeugetier;
}

void Haustier::print()

{
	cout<<"Typ: Haustier"<<endl;
	cout<<"Name: "<< name<<endl;
	cout<<"Alter: "<< alter<<endl;
	std::cout << std::boolalpha;
	cout<<"Saugetier? "<< istSaeugetier<<endl<<endl;
}

void Haustier::plus()

{
    this->alter = alter + 1;
}
