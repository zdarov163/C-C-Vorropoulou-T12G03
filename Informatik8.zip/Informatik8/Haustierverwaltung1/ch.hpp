#include "tier.hpp"

class Chinchilla:public Haustier

{
    public:
    Chinchilla(std::string name, int alter, bool istSaeugetier);
    void print();
    void plus();
};