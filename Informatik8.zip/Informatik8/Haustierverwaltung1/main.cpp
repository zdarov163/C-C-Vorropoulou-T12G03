#include <iostream>
#include <string>
#include "ch.hpp"
#include "ig.hpp"

using namespace std;


int main()
{
	Chinchilla ch = Chinchilla("Chilli", 4, 1);
	Weissbauchigel ig = Weissbauchigel("Isolde", 9, 1);
	ch.print();
	ig.print();
	
	ch.plus();
	cout<<"Eigenschaften der Chinchilla nach einem Jahr"<<endl;
	ch.print();
	
	
	return 0;
}
