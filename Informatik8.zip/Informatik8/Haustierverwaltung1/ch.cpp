#include "ch.hpp"
#include <iostream>

using namespace std;

Chinchilla::Chinchilla(std::string name, int alter, bool istSaeugetier):Haustier(name, alter, istSaeugetier)

{
    this->name = name;
    this->alter = alter;
    this->istSaeugetier = istSaeugetier;
}

void Chinchilla::print()

{
    cout<<"Typ: Chinchilla"<<endl;
    cout<<"Name: "<< name<<endl;
	cout<<"Alter: "<< alter<<endl;
	std::cout << std::boolalpha;
	cout<<"Saugetier? "<< istSaeugetier<<endl<<endl;
}

void Chinchilla::plus()

{
    this->alter = alter + 1;
}