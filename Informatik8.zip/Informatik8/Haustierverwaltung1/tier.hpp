#ifndef TIER_HPP
#define TIER_HPP

#include <string>

class Haustier
{
public:
	std::string name;
	int alter;
	bool istSaeugetier;
	Haustier(std::string name, int alter, bool istSaeugetier);
	void print();
	void plus();
};


#endif