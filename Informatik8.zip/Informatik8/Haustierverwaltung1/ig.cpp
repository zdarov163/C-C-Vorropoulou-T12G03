#include "ig.hpp"
#include <iostream>

using namespace std;

Weissbauchigel::Weissbauchigel(std::string name, int alter, bool istSaeugetier):Haustier(name, alter, istSaeugetier)

{
    this->name = name;
    this->alter = alter;
    this->istSaeugetier = istSaeugetier;
}

void Weissbauchigel::print()

{
    cout<<"Typ: Weissbauchigel"<<endl;
    cout<<"Name: "<< name<<endl;
	cout<<"Alter: "<< alter<<endl;
	std::cout << std::boolalpha;
	cout<<"Saugetier? "<< istSaeugetier<<endl<<endl;
}

void Weissbauchigel::plus()

{
    this->alter = alter + 1;
}