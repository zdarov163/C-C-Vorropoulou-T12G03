#include <iostream>
#include <string>
#include "ch.hpp"
#include "ig.hpp"


int main()
{
    
    Igel ig =  {"", 0, 1};
	Chinchilla ch = {"", 0, 1};
	
	ig.anweisen();
	ch.anweisen();
	
	ig.print();
	ch.print();
	
	
	
	return 0;
}
