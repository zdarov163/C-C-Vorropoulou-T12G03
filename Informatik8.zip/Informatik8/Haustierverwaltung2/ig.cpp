#include "ig.hpp"
#include <iostream>

using namespace std;

Igel::Igel(std::string name, int alter, bool istSaeugetier):Haustier(name, alter, istSaeugetier)

{
    this->name = name;
    this->alter = alter;
    this->istSaeugetier = istSaeugetier;
}

void Igel::print()

{
    cout<<"Weissbauchigel"<<endl;
    cout<<"Name: "<< name<<endl;
	cout<<"Alter: "<< alter<<endl;
	std::cout << std::boolalpha;
	cout<<"Saugetier? "<< istSaeugetier<<endl<<endl;
}

void Igel::plus()

{
    this->alter = alter + 1;
}

void Igel::anweisen()

{
	cout<<"Name: "<<endl;
	getline(cin, name);
	cout<<"Alter: "<<endl;
	cin>>alter;
	cout<<"Saugetier? "<<endl;
	cin>>istSaeugetier;
	cout<<"\n"<<endl;
}