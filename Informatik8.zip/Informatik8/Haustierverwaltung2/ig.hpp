#include "ht.hpp"

class Igel:public Haustier

{
    public:
    Igel(std::string name, int alter, bool istSaeugetier);
    void anweisen();
    void print();
    void plus();
};