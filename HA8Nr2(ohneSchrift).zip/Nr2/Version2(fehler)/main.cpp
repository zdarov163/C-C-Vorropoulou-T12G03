/*Hauptprogramm*/
#include <iostream>
#include <string>
#include "ch.hpp"
#include "ig.hpp"


int main()
{
    
    Igel ig =  {"", 0, 1};                  //Deklaration des Objektes "Weissbauchigel". Anweisung der urspruenglichen Attributen
	Chinchilla ch = {"", 0, 1};             //Deklaration des Objektes "Chinchilla". Anweisung der urspruenglichen Attributen
	
	ig.anweisen();                          //Aenderung der urspruenglichen Attributen von "Weissbauchigel"
	ch.anweisen();                          //Aenderung der urspruenglichen Attributen von "Chinchilla"
	
	ig.print();                             //Ausgabe: Fehler
	ch.print();                             //Ausgabe: Fehler
	
	
	
	return 0;
}
