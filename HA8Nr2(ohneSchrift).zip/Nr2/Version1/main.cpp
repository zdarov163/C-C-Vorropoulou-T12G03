/*Hauptprogramm*/

#include <iostream>
#include <string>
#include "ch.hpp"
#include "ig.hpp"

using namespace std;


int main()
{
	Chinchilla ch = Chinchilla("Chilli", 4, 1);                 //Deklaration des Objektes "Chinchilla". Anweisung der Attributen
	Weissbauchigel ig = Weissbauchigel("Isolde", 9, 1);         //Deklaration des Objektes "Weissbauchigel". Anweisung der Attributen
	ch.print();                                                 //Ausgabe der urspruenglichen Attributen von "Chinchilla"
	ig.print();                                                 //Ausgabe der urspruenglichen Attributen von "Weissbauchigel"
	
	ch.plus();                                                  //Vergroesserung des Attributes "Alter" von "Chinchilla" um 1
	cout<<"Eigenschaften der Chinchilla nach einem Jahr"<<endl;
	ch.print();                                                 //Ausgabe der Attributen von "Chinchilla" mit geaendertem Attribut "Alter"
	
	
	return 0;
}
