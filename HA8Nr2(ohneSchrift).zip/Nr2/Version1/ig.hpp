/*Headerdatei der erbenden Klasse Weissbauchigel*/
#include "tier.hpp"

class Weissbauchigel:public Haustier

{
    public:
    Weissbauchigel(std::string name, int alter, bool istSaeugetier);
    void print();
    void plus();
};