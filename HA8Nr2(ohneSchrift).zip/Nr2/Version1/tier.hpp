/*Headerdatei der Klasse Haustier*/
#ifndef TIER_HPP
#define TIER_HPP

#include <string>

class Haustier
{
public:
	std::string name;
	int alter;
	bool istSaeugetier;
	Haustier(std::string name, int alter, bool istSaeugetier); //Objekt der Klasse Haustier
	void print();       //Ausgabe der Attributen vom Objekt
	void plus();        //Vergroesserung von dem Attribut "Alter" des Objektes
};


#endif